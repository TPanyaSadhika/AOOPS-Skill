package contactmanager;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class ContactManager {
    // Map to store contacts (name as key, phone number as value)
    private Map<String, String> contacts;

    // Constructor to initialize the contacts map
    public ContactManager() {
        contacts = new HashMap<>();
    }

    // Method to add a contact
    public void addContact(String name, String phoneNumber) {
        contacts.put(name, phoneNumber);
        System.out.println("Contact added: " + name);
    }

    // Method to remove a contact
    public void removeContact(String name) {
        if (contacts.remove(name) != null) {
            System.out.println("Contact removed: " + name);
        } else {
            System.out.println("Contact not found.");
        }
    }

    // Method to retrieve a contact's phone number
    public String getPhoneNumber(String name) {
        return contacts.get(name);
    }

    // Method to list all contacts
    public void listContacts() {
        if (contacts.isEmpty()) {
            System.out.println("No contacts available.");
        } else {
            System.out.println("Contacts:");
            for (Map.Entry<String, String> entry : contacts.entrySet()) {
                System.out.println("Name: " + entry.getKey() + ", Phone Number: " + entry.getValue());
            }
        }
    }

    // Main method to demonstrate the ContactManager class
    public static void main(String[] args) {
        ContactManager manager = new ContactManager();
        Scanner scanner = new Scanner(System.in);
        
        // Adding contacts
        manager.addContact("Alice", "123-456-7890");
        manager.addContact("Bob", "987-654-3210");
        manager.addContact("Charlie", "555-123-4567");

        // Retrieving and displaying a contact's phone number
        System.out.println("Phone number for Alice: " + manager.getPhoneNumber("Alice"));

        // Removing a contact
        manager.removeContact("Bob");

        // Listing all contacts
        manager.listContacts();
        
        scanner.close();
    }
}
