package com.student.management;

import java.util.ArrayList;
import java.util.List;

public class StudentManager implements IStudentManager {
    private List<Student> students = new ArrayList<>();

    @Override
    public void addStudent(Student student) {
        students.add(student);
    }

    @Override
    public List<Student> getStudents() {
        return students;
    }
}