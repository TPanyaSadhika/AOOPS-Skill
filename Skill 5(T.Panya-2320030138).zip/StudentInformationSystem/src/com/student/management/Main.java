package com.student.management;

public class Main {
    public static void main(String[] args) {
        IStudentManager studentManager = new StudentManager();
        ICourseManager courseManager = new CourseManager();
        Student student1 = new Student("S1", "Alice");
        Student student2 = new Student("S2", "Bob");

        Course course1 = new Course("C1", "Mathematics");
        Course course2 = new Course("C2", "Physics");

        studentManager.addStudent(student1);
        studentManager.addStudent(student2);
        courseManager.addCourse(course1);
        courseManager.addCourse(course2);

        EnrollmentService enrollmentService = new EnrollmentService(studentManager, courseManager);
        enrollmentService.enrollStudentInCourse("S1", "C1");
        enrollmentService.enrollStudentInCourse("S2", "C2");
    }
}