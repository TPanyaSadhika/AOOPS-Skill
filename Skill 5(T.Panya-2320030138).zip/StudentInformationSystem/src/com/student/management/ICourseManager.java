package com.student.management;

import java.util.List;

public interface ICourseManager {
    void addCourse(Course course);
    List<Course> getCourses();
}