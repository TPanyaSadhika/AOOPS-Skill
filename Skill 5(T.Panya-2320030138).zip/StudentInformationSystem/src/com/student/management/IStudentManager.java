package com.student.management;

import java.util.List;

public interface IStudentManager {
    void addStudent(Student student);
    List<Student> getStudents();
}