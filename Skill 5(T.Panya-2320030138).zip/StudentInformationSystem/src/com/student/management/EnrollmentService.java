package com.student.management;

public class EnrollmentService {
    private final IStudentManager studentManager;
    private final ICourseManager courseManager;

    public EnrollmentService(IStudentManager studentManager, ICourseManager courseManager) {
        this.studentManager = studentManager;
        this.courseManager = courseManager;
    }

    public void enrollStudentInCourse(String studentId, String courseId) {
        Student student = studentManager.getStudents().stream()
                .filter(s -> s.getId().equals(studentId))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Student not found"));
        
        Course course = courseManager.getCourses().stream()
                .filter(c -> c.getCourseId().equals(courseId))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Course not found"));
        
        student.enrollInCourse(course);
        course.enrollStudent(student);
        
        System.out.println(student.getName() + " enrolled in " + course.getCourseName());
    }
}