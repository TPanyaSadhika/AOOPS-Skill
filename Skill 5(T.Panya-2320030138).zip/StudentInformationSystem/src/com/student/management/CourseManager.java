package com.student.management;

import java.util.ArrayList;
import java.util.List;

public class CourseManager implements ICourseManager {
    private List<Course> courses = new ArrayList<>();

    @Override
    public void addCourse(Course course) {
        courses.add(course);
    }

    @Override
    public List<Course> getCourses() {
        return courses;
    }
}