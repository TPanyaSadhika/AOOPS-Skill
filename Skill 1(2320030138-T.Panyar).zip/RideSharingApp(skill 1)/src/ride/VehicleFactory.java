package ride;

abstract class VehicleFactory {
    public abstract Vehicle createVehicle();
}