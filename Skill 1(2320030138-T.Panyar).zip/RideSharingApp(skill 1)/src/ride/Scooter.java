package ride;

class Scooter implements Vehicle {
    @Override
    public void drive() {
        System.out.println("Scooter is driving.");
    }
}