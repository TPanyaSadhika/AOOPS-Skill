package ride;

abstract class PaymentFactory {
    public abstract PaymentMethod createPaymentMethod();
}
