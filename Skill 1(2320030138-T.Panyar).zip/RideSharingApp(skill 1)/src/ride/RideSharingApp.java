package ride;

public class RideSharingApp {
    public static void main(String[] args) {
        // Step 1: User Authentication (Singleton)
        UserAuthentication auth = UserAuthentication.getInstance();
        auth.login("john_doe");

        // Step 2: Request a Vehicle (Factory Method)
        VehicleFactory vehicleFactory = new CarFactory(); // Choose Car
        Vehicle vehicle = vehicleFactory.createVehicle();
        vehicle.drive();

        // Step 3: Choose Payment Method (Abstract Factory)
        PaymentFactory paymentFactory = new CreditCardPaymentFactory(); // Choose Credit Card
        PaymentMethod paymentMethod = paymentFactory.createPaymentMethod();
        paymentMethod.pay(50.0);  // Pay 50 units

        // Step 4: User logs out
        auth.logout();
    }
}
