package ride;

//Vehicle interface
interface Vehicle {
 void drive();
}
