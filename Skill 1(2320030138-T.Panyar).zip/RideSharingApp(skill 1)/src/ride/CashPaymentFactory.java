package ride;

class CashPaymentFactory extends PaymentFactory {
    @Override
    public PaymentMethod createPaymentMethod() {
        return new CashPayment();
    }
}