package ride;


interface PaymentMethod {
    void pay(double amount);
}