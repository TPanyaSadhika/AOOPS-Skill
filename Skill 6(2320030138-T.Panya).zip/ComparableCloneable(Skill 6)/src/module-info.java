/**
 * 
 */
/**
 * 
 */
module ComparableCloneable {
}