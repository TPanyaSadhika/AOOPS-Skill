package employee;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class Main {
    public static void main(String[] args) throws CloneNotSupportedException {
        // Create a list of employees
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee(3, "Alice", 50000));
        employees.add(new Employee(1, "Bob", 60000));
        employees.add(new Employee(2, "Charlie", 55000));

        // Display original list
        System.out.println("Original List:");
        for (Employee e : employees) {
            System.out.println(e);
        }

        // Sorting employees by ID (natural order using Comparable)
        Collections.sort(employees);
        System.out.println("\nSorted by ID (natural order):");
        for (Employee e : employees) {
            System.out.println(e);
        }

        // Sorting employees by salary using Comparator
        Collections.sort(employees, new EmployeeSalaryComparator());
        System.out.println("\nSorted by Salary:");
        for (Employee e : employees) {
            System.out.println(e);
        }

        // Sorting employees by name using Comparator
        Collections.sort(employees, new EmployeeNameComparator());
        System.out.println("\nSorted by Name:");
        for (Employee e : employees) {
            System.out.println(e);
        }

        // Cloning an employee
        Employee clonedEmployee = (Employee) employees.get(0).clone();
        System.out.println("\nCloned Employee: " + clonedEmployee);

        // Iterating over the employee list using Iterator
        System.out.println("\nIterating through employees:");
        Iterator<Employee> iterator = employees.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }
    }
}

