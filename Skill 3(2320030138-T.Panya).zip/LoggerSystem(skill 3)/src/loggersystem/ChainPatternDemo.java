package loggersystem;

public class ChainPatternDemo {

    private static Logger getChainOfLoggers() {

        Logger errorLogger = new ErrorLogger(Logger.ERROR);
        Logger debugLogger = new DebugLogger(Logger.DEBUG);
        Logger infoLogger = new InfoLogger(Logger.INFO);

        // Setting up the chain of responsibility
        errorLogger.setNextLogger(debugLogger);
        debugLogger.setNextLogger(infoLogger);

        return errorLogger;
    }

    public static void main(String[] args) {
        Logger loggerChain = getChainOfLoggers();

        System.out.println("Logging INFO message:");
        loggerChain.logMessage(Logger.INFO, "This is an informational message.");

        System.out.println("\nLogging DEBUG message:");
        loggerChain.logMessage(Logger.DEBUG, "This is a debug level message.");

        System.out.println("\nLogging ERROR message:");
        loggerChain.logMessage(Logger.ERROR, "This is an error message.");
    }
}
