package employeemanagementsystem;

import java.util.*;
import java.util.stream.Collectors;

public class EmployeeManagementSystem {
    public static void main(String[] args) {
        // Create a list of employees
        List<Employee> employees = Arrays.asList(
            new Employee(1, "Alice", "IT", 75000, 30),
            new Employee(2, "Bob", "HR", 60000, 40),
            new Employee(3, "Charlie", "Finance", 85000, 35),
            new Employee(4, "David", "IT", 95000, 28),
            new Employee(5, "Eve", "Finance", 55000, 25),
            new Employee(6, "Frank", "HR", 70000, 45)
        );

        // 1. Filter employees based on department
        String departmentToFilter = "IT";
        List<Employee> itEmployees = employees.stream()
            .filter(emp -> emp.getDepartment().equals(departmentToFilter))
            .collect(Collectors.toList());

        System.out.println("Employees in IT department:");
        itEmployees.forEach(System.out::println);

        // 2. Sort employees by salary in descending order
        List<Employee> sortedBySalary = employees.stream()
            .sorted(Comparator.comparingDouble(Employee::getSalary).reversed())
            .collect(Collectors.toList());

        System.out.println("\nEmployees sorted by salary (descending):");
        sortedBySalary.forEach(System.out::println);

        // 3. Group employees by department
        Map<String, List<Employee>> groupedByDepartment = employees.stream()
            .collect(Collectors.groupingBy(Employee::getDepartment));

        System.out.println("\nEmployees grouped by department:");
        groupedByDepartment.forEach((department, employeeList) -> {
            System.out.println(department + ":");
            employeeList.forEach(System.out::println);
        });

        // 4. Find the highest-paid employee
        Employee highestPaidEmployee = employees.stream()
            .max(Comparator.comparingDouble(Employee::getSalary))
            .orElse(null);

        System.out.println("\nHighest-paid employee:");
        System.out.println(highestPaidEmployee);

        // 5. Calculate the average salary of employees in a department
        String departmentForAverageSalary = "Finance";
        double averageSalary = employees.stream()
            .filter(emp -> emp.getDepartment().equals(departmentForAverageSalary))
            .mapToDouble(Employee::getSalary)
            .average()
            .orElse(0.0);

        System.out.println("\nAverage salary in Finance department: " + averageSalary);

        // 6. List the names of employees who earn more than a specified amount
        double salaryThreshold = 60000;
        List<String> highEarners = employees.stream()
            .filter(emp -> emp.getSalary() > salaryThreshold)
            .map(Employee::getName)
            .collect(Collectors.toList());

        System.out.println("\nEmployees earning more than " + salaryThreshold + ":");
        highEarners.forEach(System.out::println);
    }
}

